﻿using System.Globalization;
using System.Threading;

public class StartUp
{
    static void Main()
    {
        var engine = new Engine();
        engine.Run();
    }
}