﻿class StartUp
{
    static void Main()
    {
        var engine = new Engine();
        engine.Run();
    }
}