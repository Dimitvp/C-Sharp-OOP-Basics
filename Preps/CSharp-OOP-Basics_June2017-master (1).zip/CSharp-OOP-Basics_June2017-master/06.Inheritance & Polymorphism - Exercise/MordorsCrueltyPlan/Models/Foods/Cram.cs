﻿namespace MordorsCrueltyPlan.Models.Foods
{
    public class Cram : Food
    {
        private const int HapinessPoints = 2;
        public Cram() : base(HapinessPoints)
        {
        }
    }
}
