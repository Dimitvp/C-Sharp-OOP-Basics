﻿namespace MordorsCrueltyPlan.Models.Foods
{
    public class Lembas : Food
    {
        private const int HapinessPoints = 3;
        public Lembas() : base(HapinessPoints)
        {
        }
    }
}
