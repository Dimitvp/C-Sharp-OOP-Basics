﻿namespace MordorsCrueltyPlan.Models.Foods
{
    public class Junk : Food
    {
        private const int HapinessPoints = -1;
        public Junk() : base(HapinessPoints)
        {
        }
    }
}
