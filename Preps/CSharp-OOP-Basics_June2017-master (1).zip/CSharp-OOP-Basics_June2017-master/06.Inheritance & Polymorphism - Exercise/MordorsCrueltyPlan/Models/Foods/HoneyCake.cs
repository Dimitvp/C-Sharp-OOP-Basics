﻿namespace MordorsCrueltyPlan.Models.Foods
{
    public class HoneyCake : Food
    {
        private const int HapinessPoints = 5;
        public HoneyCake() : base(HapinessPoints)
        {
        }
    }
}
