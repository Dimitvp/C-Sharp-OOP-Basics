﻿namespace MordorsCrueltyPlan.Models.Moods
{
    public class Angry : Mood
    {
        private const string MoodName = "Angry";
        public Angry() : base(MoodName)
        {
        }
    }
}
