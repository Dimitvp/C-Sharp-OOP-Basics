﻿public static class Constants
{
}
