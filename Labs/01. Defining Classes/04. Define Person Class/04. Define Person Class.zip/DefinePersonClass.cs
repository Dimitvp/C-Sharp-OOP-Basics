﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.Define_Person_Class
{
    class DefinePersonClass
    {
        static void Main(string[] args)
        {
        }
    }
}
