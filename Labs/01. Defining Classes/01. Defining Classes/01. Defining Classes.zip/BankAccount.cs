﻿
    class BankAccount
    {
        private int id;
        private double balance;

        public int ID { get; set; }
        public double Balance { get; set; }
    }