﻿using System.Collections.Generic;

class StackOfStrings
{
    private List<string> data;

    public void Push(string elemnt)
    {
        
    }

    public string Pop()
    {
        return "";
    }

    public string Peek()
    {
        return "";
    }

    public bool IsEmpty()
    {
        return true;
    }
}