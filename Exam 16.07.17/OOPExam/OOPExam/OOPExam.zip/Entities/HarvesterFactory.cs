﻿class HarvesterFactory
    {

    }