﻿namespace _16.ExtractHyperlinks
{
    public class StartUp
    {
        public static void Main()
        {
        }
    }
}