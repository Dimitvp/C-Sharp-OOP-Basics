﻿namespace _15.MelrahShake
{
    public class StartUp
    {
        public static void Main()
        {
        }
    }
}