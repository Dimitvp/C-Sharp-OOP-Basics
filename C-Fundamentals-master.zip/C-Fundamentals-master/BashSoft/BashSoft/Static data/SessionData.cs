﻿using System.IO;

namespace BashSoft
{
    internal class SessionData
    {
        public static string currentPath = Directory.GetCurrentDirectory();
    }
}