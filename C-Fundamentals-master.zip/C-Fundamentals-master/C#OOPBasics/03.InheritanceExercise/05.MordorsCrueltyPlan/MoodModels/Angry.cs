﻿namespace _05.MordorsCrueltyPlan.MoodModels
{
    public class Angry : Mood
    {
    }
}