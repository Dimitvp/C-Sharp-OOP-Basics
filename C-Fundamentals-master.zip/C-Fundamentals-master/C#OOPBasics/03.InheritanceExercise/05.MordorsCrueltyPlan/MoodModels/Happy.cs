﻿namespace _05.MordorsCrueltyPlan.MoodModels
{
    public class Happy : Mood
    {
    }
}