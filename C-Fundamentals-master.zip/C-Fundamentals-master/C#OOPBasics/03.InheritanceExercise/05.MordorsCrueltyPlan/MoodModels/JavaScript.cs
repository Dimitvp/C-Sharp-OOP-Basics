﻿namespace _05.MordorsCrueltyPlan.MoodModels
{
    public class JavaScript : Mood
    {
    }
}