﻿namespace _05.MordorsCrueltyPlan.MoodModels
{
    public class Sad : Mood
    {
    }
}