﻿namespace _05.MordorsCrueltyPlan.FoodModels
{
    public class Other : Food
    {
        public Other()
            : base(-1)
        {
        }
    }
}