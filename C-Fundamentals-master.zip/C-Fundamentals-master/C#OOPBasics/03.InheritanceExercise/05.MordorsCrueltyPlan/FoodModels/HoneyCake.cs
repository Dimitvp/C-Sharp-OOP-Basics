﻿namespace _05.MordorsCrueltyPlan.FoodModels
{
    public class HoneyCake : Food
    {
        public HoneyCake()
            : base(5)
        {
        }
    }
}