﻿namespace _05.MordorsCrueltyPlan.FoodModels
{
    public class Lembas : Food
    {
        public Lembas()
            : base(3)
        {
        }
    }
}