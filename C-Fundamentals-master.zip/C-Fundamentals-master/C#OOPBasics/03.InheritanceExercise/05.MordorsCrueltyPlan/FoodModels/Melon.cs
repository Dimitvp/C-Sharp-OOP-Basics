﻿namespace _05.MordorsCrueltyPlan.FoodModels
{
    public class Melon : Food
    {
        public Melon()
            : base(1)
        {
        }
    }
}