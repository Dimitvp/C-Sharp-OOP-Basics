﻿namespace _05.MordorsCrueltyPlan.FoodModels
{
    public class Cram : Food
    {
        public Cram()
            : base(2)
        {
        }
    }
}