﻿namespace _14.CatLady
{
    public class StreetExtraordinaire : Breed
    {
        public StreetExtraordinaire(string type, double specificate) : base(type, specificate)
        {
        }
    }
}