﻿namespace _14.CatLady
{
    public class Siamese : Breed
    {
        public Siamese(string type, double specificate) : base(type, specificate)
        {
        }
    }
}